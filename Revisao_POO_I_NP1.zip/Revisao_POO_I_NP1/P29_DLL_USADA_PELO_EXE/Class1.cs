﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P29_DLL_USADA_PELO_EXE
{
    public class ClasseNaDLL
    {
        public string Nome { get; set; }

        public ClasseNaDLL()
        {
            this.Nome = "Nome_" + DateTime.Now.Millisecond.ToString("000");
        }
    }
}
