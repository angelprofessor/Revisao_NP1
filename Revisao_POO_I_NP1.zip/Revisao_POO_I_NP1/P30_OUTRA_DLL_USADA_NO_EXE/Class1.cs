﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P30_OUTRA_DLL_USADA_NO_EXE
{
    public class ClasseEmOutraDLL
    {
        public string GerarNome()
        {
            string ret = "Nome_";

            ret += DateTime.Now.Year.ToString() + "/" +
                DateTime.Now.Month.ToString() + "/" +
                DateTime.Now.Day.ToString() + "___" +
                DateTime.Now.Hour.ToString() + ":" +
                DateTime.Now.Minute.ToString() + ":" +
                DateTime.Now.Second.ToString()
                ;

            return ret;
        }
    }
}
