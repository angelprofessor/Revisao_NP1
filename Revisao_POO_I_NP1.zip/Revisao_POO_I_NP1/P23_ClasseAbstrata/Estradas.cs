﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P23_ClasseAbstrata
{

    //classes abstrstas tem um comportamento parecido com
    //as interfaces porem oferecem mais recursos
    //classes abstratas NAO podem ser instanciadas
    public abstract class Estradas
    {
        protected string Desig;
        protected int Minimo;
        protected int Maximo;
            
        public Estradas(string D, int Mi, int Ma)
        {
            this.Desig=D;
            this.Minimo=Mi;
            this.Maximo=Ma; 
        }
                    
        public abstract string LerDesig();
        public abstract int LerVelocidadeMax();
        public abstract int LerVelocidadeMin();

        public void SetDesig(string des) { Desig = des; }
    }

    public class AutoEstrada : Estradas
    {
        public AutoEstrada(string D, int Mi, int Ma):base(D, Mi, Ma){}

        //IMPLEMENTANDO O METODOS ANSTRATOS
        public override string LerDesig()
        {return Desig; }
        
        public override int LerVelocidadeMax()
        {return Maximo ; }

        public override int LerVelocidadeMin()
        {return Minimo;}
    }
}
