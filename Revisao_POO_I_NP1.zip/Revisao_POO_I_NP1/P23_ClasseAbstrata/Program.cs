﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P23_ClasseAbstrata
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoEstrada A = new AutoEstrada("AutoEstrada", 50, 120);
            Console.WriteLine("Limites para {0}", A.LerDesig());
            Console.WriteLine("Max em autoestrada: {0} km/h",
            A.LerVelocidadeMax());
            Console.WriteLine("Min em autoestrada: {0} Km/h",
            A.LerVelocidadeMin());

            //Os metodos publicos podem ser acessados pela classe filha
            A.SetDesig("AutoEstrada Maxima Velocidade");

            //UM OBJETO DO TIPO BASE PODE SER CONSTRUIDO COM UMA CLASSE FILHA
            //ISTO E UTIL QUAL POSSUIMOS VARIAS FILHAS DA CLASSE ABSTRATA
            //POREM NÃO SABE-SE QUAL CLASSE FILHA SERA UTILIZADA
            Estradas B = new AutoEstrada("AutoEstrada 2", 50, 120);
        }
    }
}
