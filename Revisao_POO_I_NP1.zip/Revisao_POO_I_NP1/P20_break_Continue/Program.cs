﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P20_break_Continue
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int j = 9; j > 7; --j)
            {
                for (int i = 5; i < j; ++i)
                {
                    if (i % 2 == 0) continue;//retorna para a linha do for
                    if (i % 7 == 0) break;//sai do for
                    Console.WriteLine("Alo Mundo");
                }
            }
        }
    }
}
