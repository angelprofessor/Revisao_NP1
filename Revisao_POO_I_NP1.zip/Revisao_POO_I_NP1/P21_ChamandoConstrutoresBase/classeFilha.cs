﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P21_ChamandoConstrutoresBase
{
    class classeFilha:classeBase
    {
        //QUANDO E CRIADO UM CONSTRUTOR
        //O CONSTRUTOR SEM PARAMETROS NAO 
        //E CRIADO AUTOMATICAMENTE
        // O CONSTRUTOR SEM PARAMETROS 
        //SO E CRIADO AUTOMATICAMENTE QUANDO 
        //NENHUM CONTRUTOR FOR CRIADO pelo programador

        public classeFilha(int k)
            : base(k) // chama o construtor da classe base
        {

        }

        public classeFilha(string  P)
            : base(P) // chama o construtor da classe base
        {

        }

        public classeFilha(double k)
            : base() // chama o construtor da classe base
        {

        }

        public string H { get { return X.ToString(); } }
    }
}
