﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P21_ChamandoConstrutoresBase
{
    class Program
    {
        static void Main(string[] args)
        {
            classeFilha f1 = new classeFilha(6);
            classeFilha f2 = new classeFilha(6.0);
            classeFilha f3 = new classeFilha("6");

            Console.WriteLine("X={0}", f1.H);
            Console.WriteLine("X={0}", f2.H);
            Console.WriteLine("X={0}", f3.H);
        }
    }
}
