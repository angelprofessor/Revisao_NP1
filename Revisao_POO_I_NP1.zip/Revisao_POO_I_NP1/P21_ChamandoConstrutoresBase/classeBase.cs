﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P21_ChamandoConstrutoresBase
{
    class classeBase
    {
        private int x;

        public classeBase()
        {
            x = 0;
        }

        public classeBase(int y)
        {
            x = y+1;
        }

        public classeBase(string z)
        {
            x = Convert.ToInt32(z)+3;
        }

        //PROPRIEDADE SO MENTE VISIVEL PARA A CLASSE FILHA
        protected int X { get { return x; } }
    }
}
