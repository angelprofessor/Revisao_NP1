﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P27_try_finally
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int x = 4, y = 2;
                double d = 2;
                d = x / y;
            }
            finally
            {
                Console.WriteLine("\n\n === Apenas para dizer que o catch nao e obrigatorio === \n\n");
            }
        }
    }
}
