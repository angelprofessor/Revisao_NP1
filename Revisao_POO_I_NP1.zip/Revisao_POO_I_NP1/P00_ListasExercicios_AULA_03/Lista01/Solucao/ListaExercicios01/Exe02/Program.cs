﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Entre com seu nome, por favor");
            string Nome = Console.ReadLine();
            Console.WriteLine("Seja Bem Vindo: {0}", Nome);
        }
    }
}
