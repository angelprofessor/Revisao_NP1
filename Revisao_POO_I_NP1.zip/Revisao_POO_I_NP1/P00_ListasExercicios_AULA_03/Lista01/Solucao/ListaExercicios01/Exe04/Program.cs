﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("2+3={0}",2 + 3);
            Console.WriteLine("40/8={0}", 40/8);
            Console.WriteLine("O resto de 15/4={0}", 15%4);
        }
    }
}
