﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Caros {0} sejam {1} ao C#", "alunos", "bem vindos");
        }
    }
}
