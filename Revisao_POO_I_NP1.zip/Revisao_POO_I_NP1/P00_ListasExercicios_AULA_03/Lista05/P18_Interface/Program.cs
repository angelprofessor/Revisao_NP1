﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P18_Interface
{
    class Program
    {

        //  A interface é uma lista de assinaturas
        // que a classe que deriva delas
        public interface Lista1
        {
            void m1();
            void m2(int x);
        }

        public interface ILista2
        {
            int m3();
            int m4(string x);
        }


        public class c1 : Lista1
        {

            public void m1()
            {
                int x = 1;
            }

            public void m2(int x)
            {
                int y = x;
            }
        }

        public class c2 : c1, ILista2
        {
            public int m3()
            {
                int x = 1;
                return x;
            }

            public int m4(string x)
            {
                int y = Convert.ToInt32(x);
                return y;
            }
        }

        public class c3 : Lista1, ILista2
        {
            public void m1()
            {
                int x = 1;
            }

            public void m2(int x)
            {
                int y = x;
            }

            public int m3()
            {
                int x = 1;
                return x;
            }

            public int m4(string x)
            {
                int y = Convert.ToInt32(x);
                return y;
            }
        }

        static void Main(string[] args)
        {
        }
    }
}
