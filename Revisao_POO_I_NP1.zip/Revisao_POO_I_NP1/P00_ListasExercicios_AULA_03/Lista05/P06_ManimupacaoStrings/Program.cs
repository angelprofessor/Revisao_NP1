﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P06_ManimupacaoStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            // As strings são um tipo de dados muito importante em programação.
            // As linguagens modernas forceçem um grande conteúdo de funções para
            // manipular strings, a seguir um pequeno exemplo de algumas das 
            // funcionalidades disponíveis. INVESTIGUE POR OUTRAS

            Console.WriteLine("Ordem e Progresso".Length); // Comprimento da string
            Console.WriteLine("A capital do Brasil " + " é Brasília");//Concatenando strings
            Console.WriteLine("no futuro teremos o homem terá uma base em marte".ToUpper());// Converte todos os cacacteres para MAÍUSCULO
            Console.WriteLine("A velocidade da luz não é o limite".Substring(16, 3)); // Pegando um sub string (podição inicio, quantidade de caracteres)
            Console.WriteLine("O Titanic afundou após colidir com um iceberg".IndexOf("afundou")); // depermina onde começa a substring na frase toda
            Console.WriteLine("Piau".CompareTo("Goias"));// compracao alfabetica
            Console.WriteLine("Goias".CompareTo("Piau"));// compracao alfabetica
            Console.WriteLine("Goias".CompareTo("Goias"));// compracao alfabetica
            Console.WriteLine("   a lua alteras as marés   ".Trim()); //O metodo Trim remove espaços no inicio e no final da string
        }
    }
}
