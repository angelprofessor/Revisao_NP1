﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P13_While
{
    class Program
    {
        static void Main(string[] args)
        {
            int i1 = 1;
            while (i1 <= 3)
            {
                Console.WriteLine("Bem vindo ao C#");
                i1++;
            }


            int i2 = 1;
            // no loop do/while sempre uma vez e garantida a execução do loop
            do
            {
                Console.WriteLine("Bem vindo ao C#");
                i2++;
            }
            while (i2 <= 3);//repare que neste usou-se 0 <=
        }
    }
}
