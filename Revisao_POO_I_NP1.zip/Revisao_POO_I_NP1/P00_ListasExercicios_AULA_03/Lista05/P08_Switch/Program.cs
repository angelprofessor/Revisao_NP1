﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P08_Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pizza: 1ou2=Pequena 3ou4=Média 5=Grande");
            Console.Write("Entre com sua escolha: ");
            string s = Console.ReadLine();
            int n = int.Parse(s);
            int cost = 0;
            switch (n)
            {
                case 1:                   
                case 2:
                    cost += 25;
                    break;
                case 3:
                    cost += 25;
                    goto case 4;
                case 4:
                    cost += 25;
                    goto case 1;
                case 5:
                    cost += 50;
                    goto case 1;
                default:
                    Console.WriteLine("Escolha Invaidda.");
                    break;
            }
            if (cost != 0)
            {
                Console.WriteLine("Total {0}  ", cost);
            }
        }
    }
}
