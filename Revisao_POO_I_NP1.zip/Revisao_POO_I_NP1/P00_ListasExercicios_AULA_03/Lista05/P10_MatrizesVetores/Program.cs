﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P10_Matrizes_OU_Vetores_OU_Arrays
{
    class Program
    {
        //apenas para demonstrar matriz de objetos
        //pode ser qualquer tipo de classse
        class Teste { public string nome { get; set; } }

        static void Main(string[] args)
        {
            #region [VETORES DE UMA DIMENSÃO]
            //matriz de inteiros
            int[] m1 = new int[3];
            m1[0] = 1;
            m1[1] = 2;
            m1[2] = 3;

            //matriz de caracteres
            char[] m2 = new char[3];
            m2[0] = 'A';
            m2[1] = '1';
            m2[2] = '%';

            //matriz de strings
            string[] m3 = new string[3];
            m3[0] = "nome 1";
            m3[1] = "nome 2";
            m3[2] = "nome 3";


            //matriz de strings
            Teste[] m4 = new Teste[3];
            Teste objeto1 = new Teste();
            Teste objeto2 = new Teste();
            Teste objeto3 = new Teste();
            m4[0] = objeto1;
            m4[1] = objeto2;
            m4[2] = objeto3;

            //ACESSANDO O OBJETO ATRAVEZ DA MATRIZ
            m4[0].nome = "NOME OBJETO 1";
            m4[1].nome = "NOME OBJETO 2";
            m4[2].nome = "NOME OBJETO 3";
            #endregion

            #region [VETORES DE MAIS UMA DIMENSÃO]
            int[,] array1 = new int[2, 2];

            array1[0, 0] = 0;
            array1[0, 1] = 1;
            array1[1, 0] = 2;
            array1[1, 1] = 3;


            int[,,] array2 = new int[2, 4, 3];

            array2[0, 0, 0] = 0;
            array2[0, 1, 0] = 1;
            array2[1, 3, 2] = 2;
            array2[1, 2, 2] = 3;
            //ETC

            #endregion

            #region [FORMAS DIFERENTES DE INICIALIZAR E DECLARAR MATRIZES]

            // Matriz de uma Dimensao.
            int[] ma1 = new int[] { 1, 2, 3 };
            // Matriz de uma Dimensao especificando o tamanho.
            int[] ma2 = new int[3] { 1, 2, 3 };
            // Matriz de duas Dimensoes.
            int[,] array2D = new int[,] { { 1, 2 }, { 3, 4 }, { 5, 6 }, { 7, 8 } };
            // A mesma matriz de duas Dimensoes especificando a dimensao.
            int[,] array2Da = new int[4, 2] { { 1, 2 }, { 3, 4 }, { 5, 6 }, { 7, 8 } };
            // Matriz de tres dimensoes Dimensoes.
            string[,] array2Db = new string[3, 2] { { "one", "two" }, { "three", "four" },
                                        { "five", "six" } };

            // Matriz de tres Dimensoes.
            int[, ,] array3D = new int[,,] { { { 1, 2, 3 }, { 4, 5, 6 } }, 
                                 { { 7, 8, 9 }, { 10, 11, 12 } } };
            // The same array with dimensions specified.
            int[, ,] array3Da = new int[2, 2, 3] { { { 1, 2, 3 }, { 4, 5, 6 } }, 
                                       { { 7, 8, 9 }, { 10, 11, 12 } } };

            // Assessando elementos do Array.
            System.Console.WriteLine(array2D[0, 0]);
            System.Console.WriteLine(array2D[0, 1]);
            System.Console.WriteLine(array2D[1, 0]);
            System.Console.WriteLine(array2D[1, 1]);
            System.Console.WriteLine(array2D[3, 0]);
            System.Console.WriteLine(array2Db[1, 0]);
            System.Console.WriteLine(array3Da[1, 0, 1]);
            System.Console.WriteLine(array3D[1, 1, 2]);


            #endregion
        }
    }
}
