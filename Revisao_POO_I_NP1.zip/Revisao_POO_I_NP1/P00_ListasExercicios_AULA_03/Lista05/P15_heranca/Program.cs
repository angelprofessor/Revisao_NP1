﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P15_heranca
{
    class Program
    {
        class c1
        {
            public int idade;
            protected int idade1;
            private int idade2;

            public string Nome { get; set; }
            protected string Nome1 { get; set; }
            private string Nome2 { get; set; }
                        
            public int m(string numerica) { return Convert.ToInt32(numerica); }
            protected int m1(string numerica) { return Convert.ToInt32(numerica); }
            private int m2(string numerica) { return Convert.ToInt32(numerica); }

            public c1()
            {
                idade2 = idade2 = idade = 0;
                Nome = Nome1 = Nome2 = string.Empty;
            }

            public c1(int i,string N)
            {
                idade2 = idade1 = idade = i;
                Nome = Nome1 = Nome2 = N;
            }
        }

        //c2 deriva de c1 e tem acesso ao que e public e protected
        //mas nao tem acesso ao privado
        class c2 : c1
        {
            char Ativado;

            public c2()
            {
                Ativado = 'A';
                idade1 = idade = 0;
                Nome = Nome1 = string.Empty;
            }

            public c2(int i,string N):base(i,N)//chama construtor da base
            {
                Ativado = 'A';
            }

        }

        static void Main(string[] args)
        {
            c1 o1 = new c1();
            c2 o2 = new c2();

            c1 o3 = new c1(10, "abc");
            c2 o4 = new c2(10, "abc");
        }
    }
}
