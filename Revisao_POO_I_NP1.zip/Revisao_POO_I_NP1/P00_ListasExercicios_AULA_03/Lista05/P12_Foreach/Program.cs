﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P12_Foreach
{
    class Program
    {
        class ABC
        {
            public string Nome { get; set; }
            public ABC(string nome)
            {
                this.Nome = nome;
            }
        }

        static void Main(string[] args)
        {

            //FOR VARRENDO UMA MATRIZ DE UMA DIMENSSAO
            string[] m1 = new string[] { "ABC", "EFG", "IJK" };
            foreach (string str in m1)
            {
                Console.WriteLine("Conteudo da Matriz {0}", str);
            }

            ABC o1 = new ABC("o1");
            ABC o2 = new ABC("o2");
            ABC o3 = new ABC("o3");

            ABC[] m2 = new ABC[] { o1, o2, o3 };

            foreach (ABC x in m2)
            {
                Console.WriteLine("Conteudo da Matriz {0}", x.Nome);
            }

        }
    }
}

