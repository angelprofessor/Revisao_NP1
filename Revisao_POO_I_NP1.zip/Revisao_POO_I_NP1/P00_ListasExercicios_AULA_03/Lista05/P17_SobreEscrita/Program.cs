﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P17_SobreEscrita
{
    class Program
    {

        class c1
        {
            //MESMO METODO POREM COM ASSINATURAS DIFERENTES
            public virtual int m1() { return 5; }
            public virtual int m1(int i) { return ++i; }
            public virtual int m1(int i, string a) { return i++; }
        }

        class c2:c1
        {
            //MESMO METODO POREM COM ASSINATURAS DIFERENTES
            public override int m1() { return 7; }
            public override int m1(int i) { return i*2; }
            //public override int m1(int i, string a) { return i*3; }
        }

        static void Main(string[] args)
        {
            c1 o1 = new c1();
            c2 o2 = new c2();

            Console.WriteLine("Valor={0}", o1.m1());
            Console.WriteLine("Valor={0}", o1.m1(5));//atencao a difetrenca de pos incremento e pre incremento
            Console.WriteLine("Valor={0}", o1.m1(5, "b"));


            Console.WriteLine("Valor={0}", o2.m1());
            Console.WriteLine("Valor={0}", o2.m1(5));//atencao a difetrenca de pos incremento e pre incremento
            Console.WriteLine("Valor={0}", o2.m1(5, "b"));
        }



    }
}
