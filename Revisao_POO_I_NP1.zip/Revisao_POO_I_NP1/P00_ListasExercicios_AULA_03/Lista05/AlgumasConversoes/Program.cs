﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P02_AlgumasConversoes
{
    class Program
    {
        static void Main(string[] args)
        {
            #region[ALGUMAS CONVERSOES]

            #region[CONVERSÕES ENTRE DADOS NUMÉRICOS]
            double D1 = 99.56;
            int I1 = (int)D1; // A ESTE TIPO DE CONVERSAO DAMOS O NOME DE CAST NO CASO HA PERDA DE INFORMAÇÃO
            Console.WriteLine(D1 + " e " + I1);
            I1 = 100;
            D1 = I1;
            Console.WriteLine(D1 + " e " + I1);
            #endregion

            #region[CONVERSÕES ENTRE DADOS NUMÉRICOS]
            string S2 = "99";
            int I2 = Convert.ToInt16(S2);
            I2 = I2 + 1;
            //Console.Clear();
            Console.WriteLine(I2);
            string X = Convert.ToString(I2);
            Console.WriteLine(X + " tem " + X.Length + " dígitos");
            #endregion

            #endregion
        }
    }
}
