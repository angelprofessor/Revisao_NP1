﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P02_AlgumasFormatacoes
{
    class Program
    {
        static void Main(string[] args)
        {
            #region [ALGUMAS FORMATAÇÕES]

            #region [ALGUNS EXEMPLOS DE ARREDONDADAMENTOS]
            Console.WriteLine("{0, 4:F2}", 4.78905);
            Console.WriteLine("{0, 4:F2}", 4.7);
            Console.WriteLine("{0, 4:F2}", 5.8954);
            Console.WriteLine("{0, 4:F2}", 5);
            Console.WriteLine();
            #endregion

            #region [ALGUNS EXEMPLOS DE PORCETAGENS]
            Console.WriteLine("{0, 4:P}", 0.456789);
            Console.WriteLine("{0, 4:P3}", 0.456789);
            Console.WriteLine("{0, 4:P1}", 0.456789);
            Console.WriteLine();
            #endregion

            #region [ALGUNS EXEMPLOS FORMATACAO DE DATAS]
            DateTime hoje = DateTime.Now; //PEGA DATA E HORA ATUAIS DO COMPUTADOR

            string datas = String.Format(
            "Short date".PadRight(26) + "{0:d}\n" +
            "Long date".PadRight(26) + "{0:D}\n" +
            "Short time".PadRight(26) + "{0:t}\n" +
            "Long time".PadRight(26) + "{0:T}\n" +
            "Full date/short time".PadRight(26) + "{0:f}\n" +
            "Full date/long time".PadRight(26) + "{0:F}\n" +
            "General date/short time".PadRight(26) + "{0:g}\n" +
            "General date/long time".PadRight(26) + "{0:G}\n" +
            "(default)".PadRight(26) + "{0}(default = 'G')\n" +
            "Month".PadRight(26) + "{0:M}\n" +
            "RFC1123".PadRight(26) + "{0:R}\n" +
            "Sortable".PadRight(26) + "{0:s}\n" +
            "Universal sortable".PadRight(26) + "{0:u} (invariant)\n" +
            "Universal full date/time".PadRight(26) + "{0:U}\n" +
            "Year".PadRight(26) + "{0:Y}\n", hoje);

            Console.WriteLine(datas);
            Console.WriteLine();
            #endregion

            #region [ALGUNS EXEMPLOS FORMATACAO DE NUMEROS]

            string numeros = String.Format(
                "Decimal".PadRight(20) + "{0:D}\n" +
                "Scientific".PadRight(20) + "{1:E}\n" +
                "Fixed point".PadRight(20) + "{1:F}\n" +
                "General".PadRight(20) + "{0:G}\n" +
                "Round trip".PadRight(20) + "{1:R}\n" +
                "Number".PadRight(20) + "{0:N}\n" +
                "Percent".PadRight(20) + "{1:P}\n" +
                "Hexadecimal".PadRight(20) + "{0:X}\n", 2500, 0.78876);
            Console.WriteLine(numeros);

            #endregion


            #endregion
        }
    }
}
