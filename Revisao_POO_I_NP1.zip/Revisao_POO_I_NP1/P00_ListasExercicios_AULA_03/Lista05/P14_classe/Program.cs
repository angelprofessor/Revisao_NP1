﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P14_classe
{
    class Program
    {        
        class Entidade
        {
            #region [ATRIBUTOS - Caracteristicas da Entidade]
            private int idade;//ATRIBUTO
            private char Sexo;//ATRIBUTO
            #endregion

            #region [Propriedades - Ocultam o acesso aos atributos - Encapsulamento - Geters e Seters]
            public int Idade { get { return idade; } set { idade = value; } }//Propriedade
            public int IdadeDobrada { get { return idade/2; } set { idade = value*2; } }//Propriedade
            public string Nome { get; set; }//Propriedade
            #endregion

            #region [Metodos]

            //Em C# e melhor usar propriedades que usar metodos do  tipo geters e seters
            #region [Metodos do tipo Geters e Seters - Ocultam o acesso aos atributos - Encapsulamento]
            public void SetIdade(int i) 
            { 
                this.idade = i*i; 
            } 
            public int GetIdade() 
            { 
                return Convert.ToInt32(Math.Sqrt(this.idade)); 
            }
            #endregion

            #region [Metodos - Indicam Comportamentos da Entidade]
            public string CalcularAlgumaRegraDeNegocio(int i, double u)
            {
                string ret = string.Empty;
                ret = (u + i).ToString();
                return ret;
            }
            #endregion


            #endregion

            #region [CONSTRUTORES Inicializar Atributos - Sobrecarregados que é uma das formas de Polimosfismo]
            public Entidade()
            {
                idade = -447;
            }

            public Entidade(string nome)
            {
                this.Nome = nome;
                idade = 999;
            }

            public Entidade(string nome, int i)
            {
                this.Nome = nome;
                this.idade = i;
            }
            #endregion
        }

        static void Main(string[] args)
        {
            Entidade objetoDaClasseEndidade = new Entidade();//usando o constritrutor sem parametros
            Entidade instanciaDaClasseEndidade = new Entidade("Nome");//usando o constritrutor com um parametros
            Entidade instanciaDoTipoEndidade = new Entidade("Nome", 4); //usando o constritrutor com dois parametros
        }
    }
}
