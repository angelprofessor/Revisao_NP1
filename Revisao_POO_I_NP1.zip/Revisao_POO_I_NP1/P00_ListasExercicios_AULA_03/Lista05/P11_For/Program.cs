﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P11_For
{
    class Program
    {
        static void Main(string[] args)
        {
            //VARIAVEL i DECLARADA FORA DO FOR
            int i = 0;
            for (i = 1; i <= 3; i++)
            {
                Console.WriteLine("Bem vindo ao C#");
            }

            // QUANDO FOR APENAS UMA INSTRUÇÃO NAO E NECESSARIO COLOCAR OS PARENTESES
            for (int z = 1; z <= 3; z++) Console.WriteLine("Bem vindo ao C#");

            //FOR VARRENDO UMA MATRIZ DE UMA DIMENSSAO
            string[] m1 = new string[] { "ABC", "EFG", "IJK" };
            for (int K = 0; K < m1.Length; K++)
            {
                Console.WriteLine("Conteudo Matriz elemento {0} e {1}", K, m1[K]);
            }

            //FOR VARRENDO UMA MATRIZ DE UMA DIMENSSAO
            int[,] m2 = new int[,] {{1,2} , {3,4}, {5,6} };

            var TotalDeDimenssoes = m2.Rank;
            int[] TamanhoDimensoes = new int[TotalDeDimenssoes];

            for (int indice = 0; indice < TamanhoDimensoes.Length; indice++) {
                TamanhoDimensoes[indice]= m2.GetLength(indice);
            }

            for (int K = 0; K < TamanhoDimensoes[0]; K++)
            {
                for (int j = 0; j < TamanhoDimensoes[1]; j++)
                {
                    Console.WriteLine("Conteudo Matriz elemento m2[{0},{1}]={2}", K, j ,m2[K,j]);
                }
               
            }
        }
    }
}
