﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P16_PoliMorficmo
{
    class Program
    {
        class c1
        {
            //MESMO METODO POREM COM ASSINATURAS DIFERENTES
            public int m1() { return 5; }
            public int m1(int i) { return ++i; }
            public int m1(int i, string a) { return i++; }
        }


        static void Main(string[] args)
        {
            c1 o1 = new c1();

            Console.WriteLine("Valor={0}", o1.m1());
            Console.WriteLine("Valor={0}", o1.m1(5));//atencao a difetrenca de pos incremento e pre incremento
            Console.WriteLine("Valor={0}", o1.m1(5,"b"));
        }
    }
}
