﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P09_If_else_if_else
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Entre um caractere alfanumetico: ");
            char ch = (char)Console.Read();

            if (Char.IsUpper(ch))
            {
                Console.WriteLine("Você entrou uma letra maíuscula.");
            }
            else if (Char.IsLower(ch))
            {
                Console.WriteLine("Você entrou uma letra minúscula..");
            }
            else if (Char.IsDigit(ch))
            {
                Console.WriteLine("Você entrou um digito.");
            }
            else
            {
                Console.WriteLine("o caractere alfanumerico.");
            }
        }
    }
}
