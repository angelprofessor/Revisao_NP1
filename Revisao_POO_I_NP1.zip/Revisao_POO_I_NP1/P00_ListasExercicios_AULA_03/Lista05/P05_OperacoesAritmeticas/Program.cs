﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P05_OperacoesAritmeticas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(4 + 5); // OPERAÇÃO DE ADICAO
            Console.WriteLine(8 - 6); // OPERAÇÃO DE SUBTRACAO
            Console.WriteLine(2 * 5);  // OPERAÇÃO DE MULTIPLICACAO
            Console.WriteLine(20/5); // OPERAÇÃO DE DIVISAO

            Console.WriteLine(40%12); // OPERAÇÃO DE RESTO DA DIVISAO  OU MODULO DA DIVISAO

            int i = 10;
            Console.WriteLine(i++); // OPERAÇÃO POS INCREMENTO
            Console.WriteLine(++i); // OPERAÇÃO PRE INCREMENTO

            Console.WriteLine(i--); // OPERAÇÃO POS DECREMENTO 
            Console.WriteLine(--i); // OPERAÇÃO PRE DECREMENTO

        }
    }
}
