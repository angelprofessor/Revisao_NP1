﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_20
{
    class Program
    {
        static void Main(string[] args)
        {
            TermometroDigital termometro = new TermometroDigital();
            termometro.GrausCelsius = 30;

            Console.WriteLine("30 graus Celsius equivales a {0} graus Fahrenheit", termometro.RetornaGrausFahrenheit());
        }
    }
}
