﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_20
{
    public class TermometroDigital
    {
        private double grausCelsius;
        private double grausFahrenheit;

        public double GrausCelsius { get { return grausCelsius; } set { grausCelsius = value; } }
        public double GrausFahrenheit { get { return grausFahrenheit; } set { grausFahrenheit = value; } }

        //Construtor SEM parametrosincicizando as temperaturas.
        public TermometroDigital() { GrausCelsius = 0; GrausFahrenheit = 0; }

        public double RetornaGrausFahrenheit()
        {
            double ret = 0;

            ret = 1.8 * GrausCelsius + 32;

            return ret;
        }
    }
}
