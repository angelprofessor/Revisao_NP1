﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_E03
{
    class Program
    {
        static void Main(string[] args)
        {
            //A classe estatcia Math possui muitas opções de funções matematicas avançadas
            Console.WriteLine(Math.Sqrt(4));
            Console.WriteLine(Math.Sin(30 * Math.PI / 180));
        }
    }
}
