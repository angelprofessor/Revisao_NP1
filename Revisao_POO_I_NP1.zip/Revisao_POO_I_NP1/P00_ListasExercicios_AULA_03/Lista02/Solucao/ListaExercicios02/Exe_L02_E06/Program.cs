﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_E06
{
    class Program
    {
        //ALGUNS TIPOS DE DADOS DA LINGUAGEM C#

        // ##### TIPOS DE DADOS LÓGICOS ##### 
        //bool	     System.Boolean	Booleano	true ou false

        // ##### TIPOS DE DADOS NUMERICOS INTEIROS COM SINAL #####
        //sbyte	    System.Byte	    Inteiro de 8-bit com sinal	-127 a 128        
        //int	    System.Int32	Inteiro de 32-bit com sinal	-2.147.483.648 a 2.147.483.647
        //long	    System.Int64	Inteiro de 64-bit com sinal	–9,223,372,036,854,775,808 a 9,223,372,036,854,775,807               
        //Short	    System.Int16	Inteiro de 16-bit com sinal	-32,768 a 32,767

        // ##### TIPOS DE DADOS NUMERICOS INTEIROS SEM SINAL #####
        //byte	    System.Sbyte	Inteiro de 8-bit sem sinal	0 a 255
        //Uint	    System.UInt32	Inteiro de 32-bit sem sinal	0 a 4,294,967,295
        //Ulong	    System.UInt64	Inteiro de 64-bit sem sinal	0 a 18,446,744,073,709,551,615
        //Ushort	System.UInt16	Inteiro de 16-bit sem sinal	0 a 65,535

        // ##### TIPOS DE DADOS NUMERICOS COM PONTO FLUTUATE (NUMEROS COM VIRGULA) #####
        //decimal	System.Decimal	Inteiro de 96-bit com sinal com 28-29 dígitos significativos	1,0 × 10-28 a 7,9 × 1028
        //double	System.Double	Flutuante IEEE 64-bit com 15-16 dígitos significativos	±5,0 × 10-324 a ±1,7 × 10308
        //float	S   ystem.Single	Flutuante IEEE 32-bit com 7 dígitos significativos	±1,5 × 10-45 a ±3,4 × 1038

        // ##### TIPOS DE DADOS ALFANUMERICOS #####
        //String	System.String	String de caracteres Unicode
        //char	System.Char	    Caracter Unicode de 16-bit	U+0000 a U+ffff

        // ##### TIPOS DE DADOS PARA OBJETOS #####
        //Object	System.Object	Classe base	

        static void Main(string[] args)
        {
            #region [NUMEROS INTEIROS]            
            sbyte S = -34;
            byte B1 = 250;
            short SH = 32000;
            ushort U = 60000;
            int I = 1000000012;
            uint UI = 3500000000;
            long L = 1532333333334581239;
            ulong UL = 14532333333334581239;

            Console.WriteLine(S + "<" + B1 + "<" + SH + "<" + U + "<");
            Console.WriteLine(I + "<" + L + "<" + UI + "<" + UL);

            #endregion

            #region [NUMEROS REAIS]
            float F = 345.3456f; //NOTE O F NO FINAL DA DECLARAÇÃO
            double D = 6.89765432127866;
            decimal DE = 1234567897654300.14567896543m;

            Console.WriteLine(F + "<" + D + "<" + DE);
            #endregion

            #region [DADOS ALFANUMERICOS E LOGICOS]
            char C = 'O';
            string ST = "FCP é o Maior";
            bool LV = true;
            bool LF = false;

            Console.WriteLine(C + " " + ST);
            Console.WriteLine(LV + " ou " + LF);
            #endregion

        }
    }
}
