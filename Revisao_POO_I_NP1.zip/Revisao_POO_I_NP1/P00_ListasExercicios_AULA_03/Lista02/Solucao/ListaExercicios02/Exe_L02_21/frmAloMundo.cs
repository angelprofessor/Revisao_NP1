﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exe_L02_21
{
    public partial class frmAloMundo : Form
    {
        public frmAloMundo()
        {
            InitializeComponent();
        }

        private void btnMensagem_Click(object sender, EventArgs e)
        {
            txtMensagem.Text = "Alô Mundo";
        }
    }
}
