﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_E09
{
    class Program
    {
        static void Main(string[] args)
        {
            double Salario = 1000, Vendas = 100, Capital = 1000;
            double Aumento = 10, Factorjuro = 1.05, Iva = 20;
            int Resto = 10;
            Salario += Aumento;
            
            Console.WriteLine("Salário depois do aumento={0}", Salario);
            Vendas -= Iva;
            Console.WriteLine("Vendas líquidas={0}", Vendas);
            Capital *= Factorjuro;
            Console.WriteLine("Capital acumulado={0}", Capital);
            Resto %= 3;
            Console.WriteLine("Resto da divisão de 10 por 3={0}", Resto);
        }
    }
}
