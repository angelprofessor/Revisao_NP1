﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_E02
{
    class Program
    {
        static void Main(string[] args)
        {
            string FraseA = "Bananas";
            string QuantidadeA = "457";
            string FraseB = "Peras";
            string QuantidadeB = "38";

            Console.WriteLine(FraseA.PadLeft(10) + QuantidadeA.PadLeft(10));
            Console.WriteLine(FraseB.PadLeft(10) + QuantidadeB.PadLeft(10));
        }
    }
}
