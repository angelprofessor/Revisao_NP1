﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_14
{
    public class Funcionario
    {
        private int NumeroMatricula;

        // O Metodo Construtor é um metodo
        // sempre com o mesmo nome da classe.
        // Quando não criamos um construtor 
        // o compilador cria automaticamente 
        // o construtor sem parametros
        // porem quando criamos um construtor 
        // o compilador não criará o construtor sem parametros
        // caso precise-se dele então deve-se criar um
        // De regra geral a finalidade do contrutor é de inicializar 
        // atributos da classe.
        public Funcionario(int Matricula)
        {
            // Neste exemplo o clausula this  
            // é dispensável, está aqui
            // para ser apresentada apenas 
            // neste inicio de estudos.
            this.NumeroMatricula = Matricula;
        }

        public Funcionario()
        {
            NumeroMatricula = 0;
        }

        // As boas praticas recomendam que se use 
        // metodos para acessar os atributos
        // este é um método do tipo geter
        public int getNumeroMatricula()
        {
            return this.NumeroMatricula;
        }

        // As boas praticas recomendam que se use 
        // metodos para acessar os atributos
        // este é um método do tipo seter
        public void setNumeroMatricula(int Matricula)
        {
            this.NumeroMatricula = Matricula;
        }
    }
}
