﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_14
{
    class Program
    {
        static void Main(string[] args)
        {
            Funcionario funcionario = new Funcionario();
            funcionario.setNumeroMatricula(10);//uso do metodo seter
            Console.WriteLine("O Número de matricula = {0}", funcionario.getNumeroMatricula()); //uso do metodo geter
        }
    }
}
