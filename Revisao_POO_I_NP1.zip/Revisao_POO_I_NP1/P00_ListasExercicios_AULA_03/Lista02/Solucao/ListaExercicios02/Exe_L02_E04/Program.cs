﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_E04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(4 == 5); // OPERAÇÃO DE COMPARAÇÃO DE IGUALDADE
            Console.WriteLine(4 != 6); // OPERAÇÃO DE COMPARAÇÃO DE DIFERENÇA
            Console.WriteLine(4 > 5);  // USO DO OPERADOR RELACIONAL MAIOR QUE >, TAMBÉM PODEM SER USADOS <, >=, <=  MENOR, MAIOR OU IGUAL E MENOR E IGUAL
            Console.WriteLine(4 < 5 && 6 > 10); // OPERAÇÃO LOGICA AND
            Console.WriteLine(40 < 50 || 60 > 90); // OPERAÇÃO LOGICA OR
            Console.WriteLine(!(40 < 50 || 60 > 90)); //// OPERAÇÃO LOGICA NOT APLICADA SOBRE UM OR
        }
    }
}
