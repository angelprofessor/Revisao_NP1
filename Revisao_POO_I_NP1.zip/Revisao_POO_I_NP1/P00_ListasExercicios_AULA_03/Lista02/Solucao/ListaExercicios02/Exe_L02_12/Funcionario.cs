﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_12
{
    public class Funcionario
    {
        public int NumeroMatricula;

        // O Metodo Construtor é um metodo
        // sempre com o mesmo nome da classe.
        // Quando não criamos um construtor 
        // o compilador cria automaticamente 
        // o construtor sem parametros
        // porem quando criamos um construtor 
        // o compilador não criará o construtor sem parametros
        // caso precise-se dele então deve-se criar um
        // De regra geral a finalidade do contrutor é de inicializar 
        // atributos da classe.
        public Funcionario(int Matricula)
        {
            // Neste exemplo o clausula this 
            // é dispensável, está aqui
            // para ser apresentada apenas 
            // neste inicio de estudos.
            this.NumeroMatricula = Matricula;
        }
    }
}
