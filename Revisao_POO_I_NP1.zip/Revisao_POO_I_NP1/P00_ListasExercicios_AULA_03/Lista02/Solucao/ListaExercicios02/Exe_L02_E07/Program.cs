﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_E07
{
    class Program
    {
        static void Main(string[] args)
        {
            #region[CONVERSÕES ENTRE DADOS NUMÉRICOS]
            double D = 99.56;
            int I = (int)D; // A ESTE TIPO DE CONVERSAO DAMOS O NOME DE CAST NO CASO HA PERDA DE INFORMAÇÃO
            Console.WriteLine(D + " e " + I);
            I = 100;
            D = I;
            Console.WriteLine(D + " e " + I);
            #endregion

            #region[CONVERSÕES ENTRE DADOS NUMÉRICOS]
            string S = "99";
            int I1 = Convert.ToInt16(S);
            I1 = I1 + 1;
            //Console.Clear();
            Console.WriteLine(I);
            string X = Convert.ToString(I);
            Console.WriteLine(X + " tem " + X.Length + " dígitos");
            #endregion
        }
    }
}
