﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_E01
{
    class Program
    {
        static void Main(string[] args)
        {
            string FraseA = "Bananas";
            string QuantidadeA = "457";
            string FraseB = "Peras";
            string QuantidadeB = "38";

            Console.WriteLine(FraseA.PadRight(10) + QuantidadeA.PadRight(10));
            Console.WriteLine(FraseB.PadRight(10) + QuantidadeB.PadRight(10));
        }
    }
}
