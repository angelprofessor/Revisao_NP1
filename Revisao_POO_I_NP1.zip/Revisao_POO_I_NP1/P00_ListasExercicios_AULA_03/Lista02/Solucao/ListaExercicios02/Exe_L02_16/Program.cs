﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluno aluno = new Aluno("Nome Aluno", 5, 5.5);

            Console.WriteLine("O aluno tem media {0}", aluno.MediaFinal());
        }
    }
}
