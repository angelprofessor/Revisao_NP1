﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_16
{
    public class Aluno
    {
        private string Nome;
        private double P1;
        private double P2;

        public Aluno(String N, double nota1, double nota2)
        {
            Nome = N;
            P1 = nota1;
            P2 = nota2;
        }

        public double MediaFinal()
        {
            return Math.Round((P1 + P2) / 2, 0,
                MidpointRounding.AwayFromZero);
        }
    }
}
