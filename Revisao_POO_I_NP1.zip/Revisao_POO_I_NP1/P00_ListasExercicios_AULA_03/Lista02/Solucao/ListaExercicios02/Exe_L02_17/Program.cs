﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_17
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluno aluno = new Aluno("Nome Aluno", 5, 5.5);

            
            Console.WriteLine("O nome do aluno e: {0}", aluno.Nome);
            Console.WriteLine("A nota da P1 e: {0}", aluno.P1);
            Console.WriteLine("A nota da P2 e: {0}", aluno.P2);

            Console.WriteLine("O aluno tem media {0}", aluno.MediaFinal());
        }
    }
}
