﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_17
{
    public class Aluno
    {
        private string nome;
        private double p1;
        private double p2;

        public string Nome { get { return nome; } } // propriedade Apenas para leitura
        public double P1 { get { return p1; } } // propriedade Apenas para leitura
        public double P2 { get { return p2; } } // propriedade Apenas para leitura

        public Aluno(String N, double nota1, double nota2)
        {
            nome = N;
            p1 = nota1;
            p2 = nota2;
        }

        public double MediaFinal()
        {
            return Math.Round((P1 + P2) / 2, 0,
                MidpointRounding.AwayFromZero);
        }
    }
}
