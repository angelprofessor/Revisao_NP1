﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_15
{
    class Program
    {
        static void Main(string[] args)
        {
            Funcionario funcionario = new Funcionario();
            funcionario.NumeroMatricula = 10;
            Console.WriteLine("O Número de matricula = {0}", funcionario.NumeroMatricula);
        }
    }
}
