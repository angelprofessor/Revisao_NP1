﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_15
{
    public class Funcionario
    {
        private int numeroMatricula;

        // A propriedades em C# parecem um atributo para quem usa a classe
        // porem são uma forma reduzida de escrever-se os metodos geter e seter
        // para os atributos. É recomendável usar as propriedades
        // pois elas são largamente utilizadas em programas mais atuais e avançados
        // portando use e abuse de propriedades.
        public int NumeroMatricula { get { return numeroMatricula; } set { numeroMatricula = value; } }

        // O Metodo Construtor é um metodo
        // sempre com o mesmo nome da classe.
        // Quando não criamos um construtor 
        // o compilador cria automaticamente 
        // o construtor sem parametros
        // porem quando criamos um construtor 
        // o compilador não criará o construtor sem parametros
        // caso precise-se dele então deve-se criar um
        // De regra geral a finalidade do contrutor é de inicializar 
        // atributos da classe.
        public Funcionario(int Matricula)
        {
            // Neste exemplo o clausula this  
            // é dispensável, está aqui
            // para ser apresentada apenas 
            // neste inicio de estudos.
            this.NumeroMatricula = Matricula;
        }

        public Funcionario()
        {
            NumeroMatricula = 0;
        }


    }
}
