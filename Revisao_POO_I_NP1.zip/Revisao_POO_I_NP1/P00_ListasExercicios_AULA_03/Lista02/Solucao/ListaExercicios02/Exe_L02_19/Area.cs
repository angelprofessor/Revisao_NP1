﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_19
{
    public class Area
    {
        public double AreaQuadrado(double lado)
        {
            return lado * lado;
        }
    }
}
