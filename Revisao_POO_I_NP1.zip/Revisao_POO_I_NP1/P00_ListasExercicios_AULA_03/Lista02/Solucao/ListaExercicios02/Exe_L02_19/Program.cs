﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L02_19
{
    class Program
    {
        static void Main(string[] args)
        {
            Area area = new Area();

            Console.WriteLine("A area de um quadrado de lado 10 e : {0}", area.AreaQuadrado(10));
        }
    }
}
