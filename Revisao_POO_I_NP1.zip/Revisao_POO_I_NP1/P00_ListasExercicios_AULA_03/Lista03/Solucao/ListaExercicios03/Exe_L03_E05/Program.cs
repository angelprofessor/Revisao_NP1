﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E05
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite a quantia em dólares: ");
            double Usd = Convert.ToDouble(Console.ReadLine());
            Console.Write("Digite o número de reais por um dólar: ");
            double Taxa = Convert.ToDouble(Console.ReadLine());
            double Reais = Usd * Taxa;
            Console.WriteLine("{0} dólares equivalem a {1} reais", Usd, Reais);
        }
    }
}
