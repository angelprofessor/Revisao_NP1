﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E11
{
    public class Viagem
    {
        #region [ATRIBUTOS]
        private double KmInicio;
        private double LInicio;
        private double KmFim;
        private double LFim;
        #endregion

        #region [CONSTRUTORES]
        /// <summary>
        /// Construtor sem parametros
        /// </summary>
        public Viagem()
        {
            KmInicio = 0;
            KmFim = 0;
            LInicio = 0;
            LFim = 0;
        }

        /// <summary>
        /// Contrutor que inicializa as leituras do inicio da viagem
        /// </summary>
        /// <param name="KmIn">Quilometragem indicada do veículo no inicio da viagem</param>
        /// <param name="LIn">Leitura de combustível indicada no inicio da viagem</param>
        public Viagem(double KmIn, double LIn)
        {
            KmInicio = KmIn;
            LInicio = LIn;
            KmFim = 0;
            LFim = 0;
        }
        #endregion

        #region [METODOS PUBLICOS]
        /// <summary>
        /// Metodo ´para registrar as medidas ao final da viagem
        /// </summary>
        /// <param name="KmFi">Leitura do odometro ao fim da viagem</param>
        /// <param name="LFi">Leitura do painel de combustivel ao término da viagem</param>
        public void LeiturasFinais(double KmFi, double LFi)
        {
            KmFim = KmFi;
            LFim = LFi;
        }

        /// <summary>
        /// Calcula o valor medio de litros comsumidos para cada 100 Km percorridos
        /// </summary>
        /// <returns></returns>
        public double ConsumoLitros()
        {
            return (LInicio - LFim) * 100 / (KmFim - KmInicio);
        }

        /// <summary>
        /// Valor gasto para cada 100km percorridos.
        /// </summary>
        /// <param name="Preco">Preço do litro de conbustível</param>
        /// <returns></returns>
        public double ConsumoValor(double Preco)
        {
            return ConsumoLitros() * Preco;
        }
        #endregion

    }
}
