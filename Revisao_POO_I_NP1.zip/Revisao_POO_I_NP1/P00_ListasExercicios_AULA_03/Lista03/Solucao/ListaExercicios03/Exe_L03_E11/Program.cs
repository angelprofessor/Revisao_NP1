﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E11
{
    class Program
    {
        static void Main(string[] args)
        {
            Viagem V = new Viagem(10000, 45);
            V.LeiturasFinais(12000, 5);
            Console.WriteLine("Consumo médio aos 100={0} litros", V.ConsumoLitros());
            Console.WriteLine("Consumo médio aos 100={0} Reais",  V.ConsumoValor(1.1));
        }
    }
}
