﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o seu nome: ");
            string Nome=Console.ReadLine();
            Console.Write("Digite o seu sobrenome: ");
            string Sobrenome= Console.ReadLine();
            Console.WriteLine("{0}, {1}",Sobrenome, Nome);
        }
    }
}
