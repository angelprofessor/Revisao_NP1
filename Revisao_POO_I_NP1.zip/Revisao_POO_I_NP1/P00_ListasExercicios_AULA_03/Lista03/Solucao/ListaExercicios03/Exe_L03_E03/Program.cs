﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o capital inicial ");
            double X = Convert.ToDouble(Console.ReadLine());
            Console.Write("Digite a taxa anual de juros (%) ");
            double I = Convert.ToDouble(Console.ReadLine());
            double Capacumulado = X * Math.Pow((1 + I / 100), 2);
            Console.WriteLine("{0} reais capitalizados durante 2 anos" +
            " à taxa anual de {1}% resultam em {2} reais",
            X, I, Capacumulado);
        }
    }
}
