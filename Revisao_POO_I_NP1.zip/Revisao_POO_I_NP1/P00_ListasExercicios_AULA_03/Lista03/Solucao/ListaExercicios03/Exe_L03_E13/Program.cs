﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E13
{
    class Program
    {
        static void Main(string[] args)
        {
            Mae mae = new Mae();
            mae.Nome = "Maria";

            Filha filha = new Filha();
            filha.Nome = "Laura";

            Console.WriteLine("Nome da Mae: {0}", mae.Nome);
            Console.WriteLine("Nome da Filha: {0}", filha.Nome);

            Console.WriteLine("Mae so faz soma exe: 5+3={0}", mae.FazerSoma(5,3));

            Console.WriteLine("Filha faz soma exe: 5+3={0}", filha.FazerSoma(5, 3));
            Console.WriteLine("Filha faz produto exe: 5*3={0}", filha.FazerProtuto(5, 3));
        }
    }
}
