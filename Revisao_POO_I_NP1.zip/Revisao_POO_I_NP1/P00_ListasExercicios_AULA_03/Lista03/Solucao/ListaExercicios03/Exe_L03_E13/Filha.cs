﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E13
{
    /// <summary>
    /// A classe filha herda da classe mae a propriedade nome
    /// e o método FazerSoma
    /// Neste exemplo chama-se a classe Mae de classe base ou superclasse
    /// e a classe filha de classe derivada ou subclasse
    /// Ha iso chama-se de herança e auxilia na reutilizaççao de código
    /// </summary>
    public class Filha:Mae
    {
        public int FazerProtuto(int num1, int num2)
        {
            return num1 * num2;
        }
    }
}
