﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E13
{
    //A CLASSE MAE PODE SER CHAMADA DE SUPERCLASSE
    //OU DE CLASSE BASE
    public class Mae
    {
        public string Nome { get; set; }

        public int FazerSoma(int num1, int num2)
        {
            return num1+num2;
        }
    }
}
