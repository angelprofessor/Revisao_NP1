﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Entre com a medida de um cateto: ");
            double C1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Entre com a medida do outro cateto: ");
            double C2 = Convert.ToDouble(Console.ReadLine());
            double H = Math.Sqrt(Math.Pow(C1, 2) + Math.Pow(C2, 2));
            Console.WriteLine("Hipotenusa={0}", H);
        }
    }
}
