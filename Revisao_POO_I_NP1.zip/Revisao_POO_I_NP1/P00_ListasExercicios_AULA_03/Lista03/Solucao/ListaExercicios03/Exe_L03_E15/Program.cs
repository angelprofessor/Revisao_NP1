﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E15
{
    class Program
    {
        static void Main(string[] args)
        {
            Amigo A = new Amigo("Nelson","Évora");
            //SOBREPOSIÇÃO DO METODO TO STRING
            Console.WriteLine(A.ToString());
        }
    }
}
