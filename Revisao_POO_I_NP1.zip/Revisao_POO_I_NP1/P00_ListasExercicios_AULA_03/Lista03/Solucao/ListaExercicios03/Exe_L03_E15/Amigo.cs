﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E15
{
    public class Amigo
    {
        private string Nome;
        private string Apelido;//Sobrenome
        public Amigo(string N, string A){Nome = N;Apelido = A;}

        //SOBREPOSIÇÃO DO METODO TO STRING
        // observe a clausula  override 
        public override string ToString(){ return Apelido + ", " + Nome; }
    }
}
