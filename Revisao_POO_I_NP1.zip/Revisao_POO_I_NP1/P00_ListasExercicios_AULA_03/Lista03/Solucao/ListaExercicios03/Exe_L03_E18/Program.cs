﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E18
{
    class Program
    {
        static void Main(string[] args)
        {
            PessoaFisica pf = new PessoaFisica();
            PessoaJuridica pj = new PessoaJuridica();

            pf.CPF = "12345678901234";
            pj.CNPJ = "12345678901234";

            Console.WriteLine("PF Doc={0}",pf.CPF);
            Console.WriteLine("PJ Doc={0}", pj.CNPJ);
        }
    }
}
