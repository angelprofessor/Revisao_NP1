﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E18
{
    //Classe Base, pode ter varias classes filhas.
    //Porem uma classe filha so pode derivar de uma classe mae 
    //em C# uma classe não pode derivar simultaneamente de mais de uma classe
    //Em c++ isso é possível
    public class Pessoa
    {
        //Os elementos de uma classe que sejam de visibilidade
        //protegida so podem de visualizados pela propria classe 
        //e por suas derivadas.
        protected string Documento;
    }
}
