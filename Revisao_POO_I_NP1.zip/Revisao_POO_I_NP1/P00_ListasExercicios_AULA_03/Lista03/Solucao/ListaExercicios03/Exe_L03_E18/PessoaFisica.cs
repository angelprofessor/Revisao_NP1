﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E18
{
    class PessoaFisica:Pessoa
    {
        public string CPF { set { Documento = value; } get { return Documento; } }
    }
}
