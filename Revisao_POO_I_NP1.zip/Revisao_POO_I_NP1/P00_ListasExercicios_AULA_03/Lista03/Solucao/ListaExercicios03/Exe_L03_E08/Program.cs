﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E08
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Valor do produto ->");
            double Vprodutos = Convert.ToDouble(Console.ReadLine());
            Console.Write("Porcentagem de desconto %->");
            double Perdesc = Convert.ToDouble(Console.ReadLine());
            Console.Write("Porcentagem de Imposto %->");
            double TaxaImposto = Convert.ToDouble(Console.ReadLine());
            double Desc = Vprodutos * Perdesc / 100;
            double Total = Vprodutos - Desc;
            double Imposto = Total * TaxaImposto / 100;
            Total += Imposto;
            Console.WriteLine("Total a pagar={0:F2} reais", Total);
        }
    }
}
