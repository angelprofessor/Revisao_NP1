﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E14
{
    public class RaizQuad
    {
        //Construtor sem parametros
        public RaizQuad(){ }

        //Metodo Sobecaregado
        public int RaizQ(int x)
        { 
            return (int)Math.Sqrt(x); 
        }

        //Metodo Sobecaregado
        public double RaizQ(double x)
        { 
            return Math.Round(Math.Sqrt(x), 2); 
        }
    }
}
