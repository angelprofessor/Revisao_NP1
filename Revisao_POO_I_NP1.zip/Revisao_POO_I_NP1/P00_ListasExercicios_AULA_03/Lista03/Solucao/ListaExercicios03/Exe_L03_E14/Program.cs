﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E14
{
    class Program
    {
        static void Main(string[] args)
        {
            RaizQuad R = new RaizQuad();
            int x = 49;
            double y = 22.50;
            Console.WriteLine("Raiz quadrada de {0}={1}", x, R.RaizQ(x));
            Console.WriteLine("Raiz quadrada de {0}={1}", y, R.RaizQ(y));
        }
    }
}
