﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E12
{
    static class Calculadora
    {
        /// <summary>
        /// Este exemplo tem por objetivo exibir uma classe
        /// estatica e destacar o fato que ela não pode
        /// ser instanciada, ou seja, ter um objeto criado.
        /// Disse que oe metodos estáticos são metodos de 
        /// classe. E os não estáticos métodos de instância
        /// </summary>
        /// <param name="num1">Parcela da soma</param>
        /// <param name="num2">Parcela da soma</param>
        /// <returns></returns>
        public static int soma(int num1, int num2)
        {
            return num1 + num2;
        }
    }
}
