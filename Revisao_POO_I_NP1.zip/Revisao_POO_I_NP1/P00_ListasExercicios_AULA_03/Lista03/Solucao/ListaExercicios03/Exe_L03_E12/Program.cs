﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E12
{
    class Program
    {
        static void Main(string[] args)
        {
            int parcela1 = 5;
            int parcela2 = 7;
            Console.WriteLine("A soma de {0} e {1} resulta {2}", parcela1, parcela2, Calculadora.soma(parcela1, parcela2));
        }
    }
}
