﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E06
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite a nota da P1: ");
            double p1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Digite a nota da P2: ");
            double p2 = Convert.ToDouble(Console.ReadLine());
            double Pim = (4.8 - ((p1+p2)*0.4))/0.2;
            Console.WriteLine("A nota minima no PIM deve ser: {0}", Pim);
        }
    }
}
