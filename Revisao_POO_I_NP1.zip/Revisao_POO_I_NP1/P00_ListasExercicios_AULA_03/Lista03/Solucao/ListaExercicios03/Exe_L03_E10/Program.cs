﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Entre com o capital inicial: ");
            double CapitalInicial = Convert.ToDouble(Console.ReadLine());
            Console.Write("Entre com o valor reagatado ao final da aplicação: ");
            double CapitalFinal = Convert.ToDouble(Console.ReadLine());

            double JurosPagos = CapitalFinal - CapitalInicial;
            double TaxaDeJuros = (JurosPagos / CapitalInicial)*100;

            Console.WriteLine("A taxa de juros para o perídodo foi de: {0} %", TaxaDeJuros);
        }
    }
}
