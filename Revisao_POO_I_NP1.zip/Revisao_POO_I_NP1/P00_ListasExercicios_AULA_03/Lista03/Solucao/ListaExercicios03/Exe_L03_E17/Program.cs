﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E17
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluno B = new Aluno("Escola 1", "Rua Algum Lugar, 0", "AlunoB", 5, 6);
            B=null;            
            System.GC.Collect();            
        }
    }
}
