﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E17
{
    class Aluno:Escola
    {
        private String Nome;
        private int Nota;

        //O CONSTRUTOR DO ALUNO CHAMA O CONSTRUTOR DA CLASSE BASE
        public Aluno(string Escola, string Local, string N, int T1, int T2): base(Escola, Local)
        {
            Nome = N;
            Nota = (int)((T1 + T2) / 2);            
            Console.WriteLine("Instanciei aluno: {0}", Nome);
        }

        //destrutor
        ~Aluno()
        {
            Console.WriteLine("Destruí aluno: {0}", Nome);
        }
        
        //Sobreposicao do metodo to stinf
        public override string ToString()
        {
            return Nome + " da escola " + base.EscNome + "(" + base.EscEndereco + ")" + " obteve " + Nota + " Valores";
        }
    }
}
