﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L03_E17
{
    class Escola
    {
        private string Nome;
        private String Endereco;
        

        //CONSTRUTOR
        public Escola(String N, string M)
        {
            Nome = N;
            Endereco = M;
            Console.WriteLine("Instanciei escola:{0}", Nome);
        }

        //DESTRUTOR
        ~Escola()
        { Console.WriteLine("Destruí escola: {0}", Nome); }


        //Propriedade
        public string EscNome
        {
            get
            { return Nome; }
            set
            { Nome = value; }
        }

        //Propriedade
        public string EscEndereco
        {
            get
            { return Endereco; }
            set
            { Endereco = value; }
        }
    }
}
