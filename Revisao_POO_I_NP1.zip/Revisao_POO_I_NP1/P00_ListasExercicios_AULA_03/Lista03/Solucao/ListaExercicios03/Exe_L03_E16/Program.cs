﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


//DECLARACAO DO NAMESPACE ESCOLA
//PARA PODER USAR A CLASSE ALUNO
using Escola;

namespace Exe_L03_E16
{
    class Program
    {
        static void Main(string[] args)
        {
            //criando um objeto do tipo aluno com o uso do Namespace
            Escola.Aluno aluno1 = new Escola.Aluno();


            //criando um objeto do tipo aluno 
            //nao foi necessario usar o name space pois o mesmo foi declarado pelo using
            Aluno aluno2 = new Aluno();

            aluno1.Nome = "Aluno 1";
            aluno2.Nome = "Aluno 2";

            Console.WriteLine("Nome aluno 1: {0}", aluno1.Nome);
            Console.WriteLine("Nome aluno 2: {0}", aluno2.Nome);
        }
    }
}

