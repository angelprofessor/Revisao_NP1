﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E13
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] mint = new int[] { 1, 2, 3, 4, 5 };
            
            Console.WriteLine("Os numeros da matriz sao: ");
            foreach (int i in mint)
            {
                Console.Write("{0} ",i);
            }
            Console.WriteLine();
        }
    }
}
