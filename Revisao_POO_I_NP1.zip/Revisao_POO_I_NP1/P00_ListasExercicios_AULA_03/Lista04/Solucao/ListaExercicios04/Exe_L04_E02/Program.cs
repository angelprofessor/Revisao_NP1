﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E02
{
    class Program
    {
        static void Main(string[] args)
        {
            const int Meiodia=12;
            int Horacorrente=DateTime.Now.Hour;
            string Msg = "";
            if (Horacorrente<Meiodia) Msg="Bom dia";
            else Msg="Boa tarde";
            Console.WriteLine (Msg);
        }
    }
}
