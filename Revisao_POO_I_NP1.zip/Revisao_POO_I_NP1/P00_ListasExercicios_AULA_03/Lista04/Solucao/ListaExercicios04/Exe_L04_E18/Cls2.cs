﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E18
{
    public class Cls2
    {
        public void m3(){}
    }
}
