﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E18
{
    class Program
    {
        static void Main(string[] args)
        {
            Cls1 c1 = new Cls1();
            I1 c11 = new Cls1();
            I2 c23 = new Cls3();

           //C1 impelemta as duas interfaces
            c1.m1();
            c1.m2();

            //c11 mesmo sendo construida por Cls1() 
            //so tem visibilidade da interface
            c11.m1();

            //c23 so tem visibilidade da interface
            c23.m2();
        }
    }
}
