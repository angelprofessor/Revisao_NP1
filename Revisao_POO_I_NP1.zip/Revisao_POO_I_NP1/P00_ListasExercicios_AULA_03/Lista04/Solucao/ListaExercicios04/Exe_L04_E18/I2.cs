﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E18
{
    //UMA INTERFACE E UMA LISTA DE ASSINATURAS.
    //AS CLASSES QUE DERIVAREM DESSA INTARFACE DEVEM IMPLEMENTAR A ASSINATURA OBRIGATORIAMENTE.
    public interface I2
    {
        int m2();
    }
}
