﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E18
{
    public class Cls1:Cls2,I1,I2
    {
        public int m1()
        {
            throw new NotImplementedException();
        }

        public int m2()
        {
            throw new NotImplementedException();
        }

        public void m4() { }
    }
}
