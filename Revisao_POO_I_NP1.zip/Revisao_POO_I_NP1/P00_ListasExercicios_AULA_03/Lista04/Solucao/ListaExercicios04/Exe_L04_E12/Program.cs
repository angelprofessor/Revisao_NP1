﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E12
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;

            // no loop do/while sempre uma vez e garantida a execução do loop
            do
            {
                Console.WriteLine("Bem vindo ao C#");
                i++;
            }
            while (i <= 10);//repare que neste usou-se 0 <=
        }
    }
}
