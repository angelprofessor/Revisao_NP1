﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E10
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            for (i = 1; i <= 10; i++)
            {
                Console.WriteLine("Bem vindo ao C#");
            }
        }
    }
}
