﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E06
{
    class Program
    {
        static void Main(string[] args)
        {
            // o operador ternario é composto pelo sinal de interrogação
            // mais o sinao de dois pontos sobrepostos ? : e equivale ao if else.
            // Antes do sinal de interrogação deve ser colocada a
            // consdição de teste, caso seja verdadeira ela retornará o resultado da
            // delaração entre os dois sinais, caso contrário retornará
            // o o resultado após o sinal de dois pontos
            Console.Write("Qual sua média Final ");
            int Nota = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine(Nota >= 5 ? "Parabéns, você esta aprovado " : "Infelizmente não foi aprovado");
        }
    }
}
