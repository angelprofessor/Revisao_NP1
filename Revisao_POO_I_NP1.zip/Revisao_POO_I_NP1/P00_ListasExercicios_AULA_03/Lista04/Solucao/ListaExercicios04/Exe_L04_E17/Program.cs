﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Unip.Turma1;

namespace Exe_L04_E17
{
    class Program
    {
        static void Main(string[] args)
        {
            Util u1 = new Util();
            Unip.Turma2.Util u2 = new Unip.Turma2.Util();

            int x = u1.dobro(2);
            int y = u2.dobro(2);
        }
    }
}
