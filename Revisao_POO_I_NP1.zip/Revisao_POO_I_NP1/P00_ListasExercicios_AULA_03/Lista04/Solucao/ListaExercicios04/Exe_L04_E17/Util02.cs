﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Unip.Turma2
{
    public class Util
    {
        public int dobro(int num) { return  num + num; }
    }
}
