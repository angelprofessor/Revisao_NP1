﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E16
{
    public class Util
    {
        //METODOS DE CLASSE
        public static int DobroUm(int num) { return num * 2; }
        public static int TriploUm(int num) { return num * 3; }

        //METODOS DE INSTANCIA
        public int DobroDois(int num) { return num * 2; }
        public int TriploDois(int num) { return num * 3; }
    }
}
