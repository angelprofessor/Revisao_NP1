﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E16
{
    class Program
    {
        static void Main(string[] args)
        {
            //METODOS DE CLASSE, SAO VISIVEIS APENAS AS CLASSES
            Console.WriteLine("DobroUM = {0}", Util.DobroUm(2));
            Console.WriteLine("TripoUM = {0}", Util.TriploUm(2));

            //PARA USAR OS METODOS DE INSTANCIA DEVE-SE CRIA UMA INSTANCIA
            //DA CLASSE, OU SEJA, UM OBJETO. NOTE-SE QUE OS METODOS DE CLASSE
            //NAO SÃO VISIVEIS AO OBJETO.
            Util util = new Util();
            Console.WriteLine("DobroUM = {0}", util.DobroDois(2));
            Console.WriteLine("TripoUM = {0}", util.TriploDois(2));        
        }
    }
}
