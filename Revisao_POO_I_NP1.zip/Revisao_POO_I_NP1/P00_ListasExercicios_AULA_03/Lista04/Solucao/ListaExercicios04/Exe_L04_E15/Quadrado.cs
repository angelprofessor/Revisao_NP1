﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E15
{
    public class Quadrado
    {
        private double lado;
        public double Lado { set { lado = value; } get { return lado; } }

        public Quadrado() { Lado = 0; }
        public Quadrado(double LadoQuadrado) { Lado = LadoQuadrado; }

        public virtual double Area()
        {
            return Lado * Lado;
        }
    }
}
