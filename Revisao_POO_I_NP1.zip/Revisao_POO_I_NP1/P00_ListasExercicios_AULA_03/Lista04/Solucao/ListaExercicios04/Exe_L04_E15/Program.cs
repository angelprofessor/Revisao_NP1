﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E15
{
    class Program
    {
        static void Main(string[] args)
        {
            Quadrado q1 = new Quadrado(10);
            Retangulo r1 = new Retangulo(10,11);
            Console.WriteLine("Q={0},R={1}", q1.Area(), r1.Area());
        }
    }
}
