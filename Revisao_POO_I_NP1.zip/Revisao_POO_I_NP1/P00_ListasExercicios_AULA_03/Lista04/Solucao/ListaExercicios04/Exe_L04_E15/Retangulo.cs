﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E15
{
    class Retangulo:Quadrado
    {
        private double lado1, lado2;
        public double Lado1 { set { lado1 = value; } get { return lado1; } }
        public double Lado2 { set { lado2 = value; } get { return lado2; } }

        public Retangulo() { Lado = 0; }
        public Retangulo(double LadoRetangulo1, double LadoRetangulo2) 
        { Lado1 = LadoRetangulo1; Lado2 = LadoRetangulo2; }

        public override double Area()
        {
            return Lado1 * Lado2;
        }
    }
}
