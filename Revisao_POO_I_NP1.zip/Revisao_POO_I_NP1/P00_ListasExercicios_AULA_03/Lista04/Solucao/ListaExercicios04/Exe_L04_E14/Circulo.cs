﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E14
{
    public class Circulo:Centro
    {
        private double Raio;
        public Circulo() { Raio = 0; }
        public Circulo(int x, int y, double R): base(x, y)//chamando o construtor da base com dois parametros
        { Raio = R; }
        public double Area()
        { return Math.Round(Math.PI * Math.Pow(Raio, 2), 2); }
    }
}
