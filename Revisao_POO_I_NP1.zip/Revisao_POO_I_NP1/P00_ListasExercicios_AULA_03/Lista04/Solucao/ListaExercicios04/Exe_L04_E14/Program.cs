﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E14
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = 4;
            Circulo[] C = new Circulo[N];
            int X = 0, Y = 0;
            double R = 0.5;
            for (int I = 0; I < C.Length; I++)
            {
                C[I] = new Circulo(X, Y, R);
                C[I].CoodCentro();
                Console.WriteLine("Área={0}", C[I].Area());
                X++;
                Y++;
                R *= 2;
            }
        }
    }
}
