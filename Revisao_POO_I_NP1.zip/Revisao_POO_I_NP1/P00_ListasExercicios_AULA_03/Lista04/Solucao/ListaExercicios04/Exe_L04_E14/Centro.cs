﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exe_L04_E14
{
    public class Centro
    {
        //coordenadas do centro
        private int x, y;
        
        //Construtor sem parametros
        public Centro(){x = 0;y = 0;}

        //Construtor com parametros
        public Centro(int x, int y){this.x = x;this.y = y;}
        
        //metodo que exibe as coordenadas do centro
        public void CoodCentro(){ Console.WriteLine("Centro = ({0}, {1})", x, y); }
    }
}
