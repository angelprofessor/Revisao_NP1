﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P24_ClasseEstatica
{
    class Program
    {
        static void Main(string[] args)
        {
            //  USANDO METODOS DE CLASSE, QUE SAO METODOS ESTATICOS
            Console.WriteLine("Dobro de {0} e {1}",3,util.Dobro(3));
            Console.WriteLine("O Numero {0} em string e {1}", 3.0, util.RetornaEmString(3.0));

            Console.WriteLine("O Numero {0} em string e {1}", 4.0, util2.RetornaEmString(4.0));

            util2 o = new util2();
            //USANDO O METODO DE INSTANCIA
            Console.WriteLine("Dobro de {0} e {1}", 5, o.Dobro(5));
        }
    }
}
