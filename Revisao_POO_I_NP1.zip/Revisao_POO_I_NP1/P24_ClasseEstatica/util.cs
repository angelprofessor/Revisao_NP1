﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P24_ClasseEstatica
{

    //classes EstaTicas NAO podem ser instanciadas
    static class util
    {
        //METODOS ESTATICOS SAO CHAMADOS METODOS DE CLASSE
        public static int Dobro(int num) { return 2 * num; }
        public static string RetornaEmString(double num) { return num.ToString(); }
    }


    //ESTA CLASSE PODE SER INSTANCIADA
    //POREM AS INSTANCIAS NAO ENCHEGAR OS METODOS ESTATICOS
    //POIS METODOS ESTATICOS SAO METODOS DE CLASSE
    // UMA CLASSE NAO ESTATICA PODE TER METODOS ESTATICOS
    class util2
    {
        //METODOS NAO ESTATICOS SAO CHAMADOS METODOS DE INSTANCIA
        public  int Dobro(int num) { return 2 * num; }

        //METODOS ESTATICOS SAO CHAMADOS METODOS DE CLASSE
        public static string RetornaEmString(double num) { return num.ToString(); }
    }


}
