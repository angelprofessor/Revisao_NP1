﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//USANDO O USING DIMINUI A DIGITACAO
//EVITANDO-SE COLCOAR O NOME COMPLETO DA CLASSE
using EspacoDeNomes1;

//O OBJETIVO PRINCIPAL DO ESPACO DE NOMES E ORGANIZAR A CODIFICACAO
namespace P22_Namespace
{
    class Program
    {
        static void Main(string[] args)
        {
            c1 o1 = new c1();

            EspacoDeNomes2.c2 o2 = new EspacoDeNomes2.c2();
        }
    }
}
