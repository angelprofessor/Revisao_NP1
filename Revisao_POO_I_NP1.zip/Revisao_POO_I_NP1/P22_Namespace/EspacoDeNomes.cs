﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace EspacoDeNomes1
{
    public class c1
    {
        public string z;
        public c1()
        {
            z = "cLASSE C1";
        }

    }
}




namespace EspacoDeNomes2
{

    public class c2
    {
        EspacoDeNomes1.c1 o1 = new EspacoDeNomes1.c1();

        public string RetornaZ { get { return o1.z; } }
    }

}
