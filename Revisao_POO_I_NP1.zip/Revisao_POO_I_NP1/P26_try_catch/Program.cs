﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P26_try_catch
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int x = 4, y = 0;
                double d = 0;                
                d = x / y;
            }
            catch (Exception ex)//PEGA QUALQUER TIPO DE EXCEPTION
            {
                Console.WriteLine("\n\n ==== Apenas para dizer que o finally nao e obrigatorio === \n\n");

                Console.WriteLine("====================== ERRO ==================\n");
                Console.WriteLine("Detalhe do Erro: \n\n" + ex.ToString() + "\n\n");
            }
        }
    }
}
