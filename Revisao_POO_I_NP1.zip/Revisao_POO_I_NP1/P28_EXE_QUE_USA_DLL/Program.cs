﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using P29_DLL_USADA_PELO_EXE;

namespace P28_EXE_QUE_USA_DLL
{
    class Program
    {
        static void Main(string[] args)
        {
            ClasseNaDLL classeNaDLL = new ClasseNaDLL();

            Console.WriteLine("Nome Gerado:{0}", classeNaDLL.Nome);

            //foi usado o nome completo da classe, ou seja, incluido o namespace
            P30_OUTRA_DLL_USADA_NO_EXE.ClasseEmOutraDLL classeNaOUTRADLL = new P30_OUTRA_DLL_USADA_NO_EXE.ClasseEmOutraDLL();

            Console.WriteLine("Nome Gerado na outra DLL:{0}", classeNaOUTRADLL.GerarNome());
        }
    }
}
