﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace P25_Try_Catch_Finally
{
    class Program
    {
        static void Main(string[] args)
        {
            int indice = 0;
            int num1=3, num2=3;
            decimal resultado;
            
NomeQualquer: //um rotulo para exibir um goto funcionando regra geral deve-se evitar o GOTO
              //Poderia ter sido feito um loop, mas foi usado apenas para verificar o uso

            try 
            {
                Console.WriteLine("======================  CASO DE TESTE {0} ==================\n", indice);
                switch (indice)
                {
                    case 0:
                        num1 = 6;
                        num2 = 0;
                        break;
                    case 1:
                        num1 = 6;
                        num2 = Convert.ToInt32("K");;
                        break;
                    case 2:
                        num1 = DateTime.Now.Millisecond;
                        string NomeArquivo = "Teste_" + num1.ToString() + ".txt";
                        File.OpenRead(NomeArquivo);
                        break;
                    case 3:
                        num1 = 6;
                        num2 = 2;
                        break;
                }

                Console.WriteLine("======================  EFETUANDO A DIVISAO ==================\n");
                resultado = (decimal)num1 / (decimal)num2;
                Console.WriteLine("Resultado Divisao: " + resultado.ToString());
                indice += 1;
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("====================== ERRO: Divisao Por zero  ==================\n");
                Console.WriteLine("Detalhe do Erro: \n\n" + ex.ToString() + "\n\n");
                indice++;//TANTO FAZ POR PRE COMO POS INCREMENTO
                goto NomeQualquer;
            }
            catch (FormatException ex)
            {
                Console.WriteLine("====================== ERRO: Entrada Invalida ==================\n");
                Console.WriteLine("Detalhe do Erro: \n\n" + ex.ToString() + "\n\n");
                ++indice;//TANTO FAZ POR PRE COMO POS INCREMENTO
                goto NomeQualquer;
            }
            catch (Exception ex)  
            {
                Console.WriteLine("====================== ERRO: Exception Não Prevista ==================\n");
                Console.WriteLine("Detalhe do Erro: \n\n" + ex.ToString() + "\n\n");
                indice++;//TANTO FAZ POR PRE COMO POS INCREMENTO
                goto NomeQualquer;
            }          
            finally 
            {
                Console.WriteLine("====================== BLOCO FINALLY: Caso de teste {0} ==================\n", indice-1);
                Console.WriteLine("O Bloco finally Sempre e executado Havendo erro ou nao, Lembrando que este bloco e opcional");
                Console.WriteLine("\n\n");
            }
        }
    }
}
