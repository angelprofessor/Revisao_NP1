﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P19_Break_Continue
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 10; ++i)
            {
                if (i % 2 == 0) continue;//retorna para a linha do for
                if (i % 7 == 0) break;//sai do for
                Console.WriteLine("Alo Mundo");
            }
        }
    }
}
